// ====================== Heart ======================
let Heart = document.querySelectorAll(".fa-heart");
if (Heart) Heart.forEach((item) => (item.onclick = (e) => e.target.classList.toggle("Heart")));

// ====================== NavBar ======================
let NavBar = document.querySelector("header .NavBar");
let OpenNavbar = document.querySelector("header .fa-bars");
let CloseNavbar = document.querySelector("header .NavBar .fa-times");
let Links = document.querySelectorAll("header .NavBar .Main");
OpenNavbar.onclick = () => {
	NavBar.classList.add("Active");
	OpenNavbar.style.opacity = "0";
	CloseNavbar.style.opacity = "1";
};
CloseNavbar.onclick = () => {
	NavBar.classList.remove("Active");
	OpenNavbar.style.opacity = "1";
	CloseNavbar.style.opacity = "0";
};
Links.forEach((link) => {
	link.onclick = () => {
		link.querySelector(".Nested-List").classList.toggle("Active");
		if (link.querySelector(".title .fas").className == "fas fa-minus Rotate") {
			link.querySelector(".title .fas").className = "fas fa-plus";
		} else {
			link.querySelector(".title .fas").className = "fas fa-minus Rotate";
		}
	};
});

// ====================== Form Setting ======================
(function () {
	"use strict";
	var forms = document.querySelectorAll(".needs-validation");
	Array.prototype.slice.call(forms).forEach(function (form) {
		form.addEventListener(
			"submit",
			function (event) {
				if (!form.checkValidity()) {
					event.preventDefault();
					event.stopPropagation();
				} else if (form.checkValidity()) {
					event.preventDefault();
					let Modal = document.querySelector(".modal.fade#ModalID");
					if (Modal) {
						Modal.setAttribute("data-Pass", "Green");
						let Currect = document.querySelector(".modal[data-pass]");
						Currect.querySelector(".modal-header h5").innerHTML = "Number Verified Successfully";
						Currect.querySelector(".modal-header img").src = "../../Images/pass-check.png";
						Currect.querySelector(".modal-body").innerHTML = "You are now successfully registered with us";
						Currect.querySelector(".modal-footer").remove();
						setInterval(() => (window.location.href = `../../HTML/Post-Form/${form.dataset.send}`), 1000);
					}
				}
				form.classList.add("was-validated");
			},
			false
		);
	});
})();

// ====================== Post-Form-1 ======================
if (document.querySelector(".Step-1")) {
	// The Desktop Select Box With Search Bar
	if (window.screen.width > 600) {
		$(".Step-1 .right .City #Select-box").select2({
			tags: true,
			placeholder: "Localities",
			maximumSelectionLength: 4,
		});
	}
	// The Mobile Select Box With Search Bar
	if (window.screen.width < 600) {
		$("body").on("shown.bs.modal", ".modal", function () {
			$(this)
				.find("select")
				.each(function () {
					var dropdownParent = $(document.body);
					if ($(this).parents(".modal.in:first").length !== 0)
						dropdownParent = $(this).parents(".modal.in:first");
					$(this).select2({
						tags: true,
						minimumInputLength: 1,
						placeholder: "Enter City",
						dropdownParent: dropdownParent,
					});
				});
		});
	}
	let Focus = setInterval(() => {
		if (document.querySelector(".select2-search__field")) {
			document.querySelector(".select2-search__field").focus();
			clearInterval(Focus);
		}
	}, 10);

	const Suggestions = document.querySelectorAll(".Localities-Modal .footer button");
	Suggestions.forEach((item) => {
		item.onclick = (e) => {
			const newOption = new Option(e.target.id, e.target.value, false, true);
			$(".Localities-Modal .body select").append(newOption).trigger("change");
		};
	});
}

// ====================== Post-Form-2 ======================
if (document.querySelector("#Step-2")) {
	const Serial = document.querySelector(".Step-2 .right .Serial");
	const Number_Field = document.querySelector(".Step-2 .right .Serial input[type='text']");
	window.onload = () => Number_Field.focus();
	Serial.onkeyup = function (e) {
		var target = e.srcElement || e.target;
		var maxLength = parseInt(target.attributes["maxlength"].value, 10);
		var myLength = target.value.length;
		if (myLength >= maxLength) {
			var next = target;
			while ((next = next.nextElementSibling)) {
				if (next == null) break;
				if (next.tagName.toLowerCase() === "input") {
					next.focus();
					break;
				}
			}
		} else if (myLength === 0) {
			var previous = target;
			while ((previous = previous.previousElementSibling)) {
				if (previous == null) break;
				if (previous.tagName.toLowerCase() === "input") {
					previous.focus();
					break;
				}
			}
		}
	};
}

// ====================== Post-Form-3 ======================
if (document.querySelector("#Step-3")) {
	$("#Step-3 .right .Apartment-Input #ApartMent-Select").select2({
		tags: true,
		placeholder: "Apartments",
		// maximumSelectionLength: 4,
	});
	// The Desktop Select Box With Search Bar
	$("#Step-3 .right .Locality #Select-box").select2({
		tags: true,
		placeholder: "Localities",
		// maximumSelectionLength: 4,
	});
	// The Mobile Select Box With Search Bar
	$("body").on("shown.bs.modal", ".modal", function () {
		$(this)
			.find("select")
			.each(function () {
				var dropdownParent = $(document.body);
				if ($(this).parents(".modal.in:first").length !== 0)
					dropdownParent = $(this).parents(".modal.in:first");
				$(this).select2({
					tags: true,
					minimumInputLength: 1,
					placeholder: "Enter City",
					dropdownParent: dropdownParent,
				});
			});
	});
	let Focus = setInterval(() => {
		if (document.querySelector(".select2-search__field")) {
			document.querySelector(".select2-search__field").focus();
			clearInterval(Focus);
		}
	}, 10);
	const Suggestions = document.querySelectorAll(".Localities-Modal .footer button");
	Suggestions.forEach((item) => {
		item.onclick = (e) => {
			const newOption = new Option(e.target.id, e.target.value, false, true);
			$(".Localities-Modal .body select").append(newOption).trigger("change");
		};
	});
}

// ====================== Post-Form-4 ======================
if (document.querySelector("#Step-4")) {
	$("#Step-4 .Expected #Year-Select").select2({ placeholder: "Years" });
}

// ====================== Post-Form-5 ======================
if (document.querySelector("#Step-5")) {
	document.querySelectorAll("#Step-5 .Parent select").forEach((item) => {
		$(`#Step-5 .Parent #${item.id}`).select2({
			tags: true,
			placeholder: "Marble",
			maximumSelectionLength: 1,
		});
	});
}

// ====================== Post-Form-6 ======================
if (document.querySelector("#Step-6")) {
	$("#Step-6 .Parent .House #House-Box").select2({ tags: true, placeholder: "House-Box", maximumSelectionLength: 1 });
}

// ====================== Post-Form-7 ======================
if (document.querySelector("#Step-7")) {
	// ======= Counter =======
	let Up = document.querySelectorAll(".Step-7 .right .Hidden-Parking  .Parking-Count .up");
	let Down = document.querySelectorAll(".Step-7 .right .Hidden-Parking .Parking-Count .down");
	Up.forEach((item) => (item.onclick = (e) => e.target.nextElementSibling.innerHTML++));
	Down.forEach((item) => {
		item.onclick = (e) => {
			if (e.target.previousElementSibling.innerHTML > 0) e.target.previousElementSibling.innerHTML--;
		};
	});

	window.onload = () => {
		const Closes = document.querySelectorAll(".box #Close");
		let Labels = document.querySelectorAll(".box label img");
		let List = [];

		if (window.File && window.FileList && window.FileReader) {
			var filesInput = document.getElementById("files");
			filesInput.addEventListener("change", (event) => {
				var files = event.target.files;
				for (var i = 0; i < files.length; i++) {
					var file = files[i];

					if (!file.type.match("image")) continue;
					var picReader = new FileReader();
					picReader.addEventListener("load", (event) => {
						Closes.forEach((cl, i) => {
							// cl.style.display = "block";
							cl.onclick = () => {
								cl.nextElementSibling.querySelector("img").src = "../../Images/back-import-file-1.png";
								cl.style.display = "none";
								List.splice(i, 1);
							};
						});
						List.push(event.target.result);
						for (i = 0; i < 4; i++) {
							if (List[i] != undefined) {
								Closes[i].style.display = "block";
								Labels[i].src = List[i];
							}
						}
					});
					picReader.readAsDataURL(file);
				}
			});
		}
	};
}
