try {
	// ===================== Reload ====================
	setTimeout(() => (document.querySelector(".Reload-Page").style.display = "none"), 500);

	// ===================== Heart =====================
	let Heart = document.querySelectorAll(".fa-heart");
	if (Heart) Heart.forEach((item) => (item.onclick = (e) => e.target.classList.toggle("Heart")));

	// ===================== NavBar ====================
	let NavBar = document.querySelector("header .NavBar");
	let OpenNavbar = document.querySelector("header .fa-bars");
	let CloseNavbar = document.querySelector("header .NavBar .fa-times");
	let Links = document.querySelectorAll("header .NavBar .Main");
	OpenNavbar.onclick = () => {
		NavBar.classList.add("Active");
		OpenNavbar.style.opacity = "0";
		CloseNavbar.style.opacity = "1";
	};
	CloseNavbar.onclick = () => {
		NavBar.classList.remove("Active");
		OpenNavbar.style.opacity = "1";
		CloseNavbar.style.opacity = "0";
	};
	Links.forEach((link) => {
		link.onclick = () => {
			link.querySelector(".Nested-List").classList.toggle("Active");
			if (link.querySelector(".title .fas").className == "fas fa-minus Rotate") {
				link.querySelector(".title .fas").className = "fas fa-plus";
			} else {
				link.querySelector(".title .fas").className = "fas fa-minus Rotate";
			}
		};
	});

	// ================== Small-Search =================
	let Open = document.querySelector(".Home .Small-Search");
	let Close = document.querySelector(".Home .Search-Filters .fa-chevron-left");

	let ButtonsForm = document.querySelectorAll(".Home .Search-Filters .Form-Buttons button");
	let FilterForm = document.querySelector(".Home .Search-Filters");
	let Clear = document.querySelector(".Home .Search-Filters .Form-Buttons .Clear-All");

	Open.onclick = () => FilterForm.classList.add("Active");
	Close.onclick = () => FilterForm.classList.remove("Active");
	Clear.onclick = () => ButtonsForm.forEach((el) => el.classList.remove("Active"));
	ButtonsForm.forEach((item) => {
		ButtonsForm.forEach((el) => el.classList.remove("Active"));
		item.onclick = (e) => e.target.classList.toggle("Active");
	});

	// The Mobile Select Box With Search Bar
	$("body").on("shown.bs.modal", ".modal", function () {
		$(this)
			.find("select")
			.each(function () {
				var dropdownParent = $(document.body);
				if ($(this).parents(".modal.in:first").length !== 0)
					dropdownParent = $(this).parents(".modal.in:first");
				$(this).select2({
					tags: true,
					minimumInputLength: 1,
					placeholder: "Enter City",
					dropdownParent: dropdownParent,
					minimumResultsForSearch: Infinity,
				});
			});
	});

	let Focus = setInterval(() => {
		if (
			document.querySelector(".Localities-Modal").classList.contains("show") &&
			document.querySelector(".Localities-Modal .select2-search__field")
		) {
			document.querySelector(".Localities-Modal .select2-search__field").focus();
			clearInterval(Focus);
		}
	}, 100);

	// Print The Selected Option In The Filter Localities Field
	let SubmitBtn = document.querySelector(".Localities-Modal .Submit-btn");
	SubmitBtn.onclick = () => {
		let SelectedOptions = document.querySelectorAll(".Localities-Modal .body .select2-container li span");
		let Field = document.querySelector(".Home .Search-Filters .Localities-City button");
		console.log(SelectedOptions);
		Field.textContent = "";
		SelectedOptions.forEach((item) => {
			Field.innerHTML += `<span>${item.nextSibling.textContent} <span>|</span> </span>`;
		});
		if (Field.textContent === "") Field.textContent = "Localities";
	};

	// Print The Suggestion Option In The Search Bar
	const Suggestions = document.querySelectorAll(".Localities-Modal .footer button");
	Suggestions.forEach((item) => {
		item.onclick = (e) => {
			const newOption = new Option(e.target.id, e.target.value, false, true);
			$(".Localities-Modal .body select").append(newOption).trigger("change");
		};
	});

	// ===================== Desktop-Search =============
	const Tabs_Btns = document.querySelectorAll(".Services .Search .Down a");
	const Tabs = document.querySelectorAll(".Services .Search .Show-Drob-Down .box");
	const Remove = ["Services", "col-6", "title", "Label"];
	const Offset = document.querySelector(".Services").offsetTop - 130;
	Tabs_Btns.forEach((item) => {
		item.onclick = (e) => {
			let DataTab = document.querySelector(e.target.dataset.tab); // Get The Element That Has DataSet = tab
			Tabs_Btns.forEach((item) => item.classList.remove("Show")); // Remove Show Class From All Dropdown Headers
			Tabs.forEach((Remove) => Remove.classList.remove("Show")); // Remove Show Class From All Dropdown Boxes
			if (DataTab) {
				item.classList.add("Show"); // Add Show Class On The Dropdown Header
				DataTab.classList.add("Show"); // Add SHow Class On The Dropdown Box
				window.scrollTo({ top: Offset, behavior: "smooth" }); // Scroll To The Top When Click On Any Dropdown Header
			}
		};
	});

	function formatState(state) {
		if (!state.id) return state.text;

		var $state = $(`<span class="Parent-Line"><span>${state.text}</span> <span>City</span>`);
		return $state;
	}
	$(".Services .Search .Mid .Catagory #Select-box").select2({
		templateResult: formatState,
		tags: true,
		minimumInputLength: 1,
	});
	document.onclick = (Click) => {
		if (
			Click.target.classList.contains("select2-selection--multiple") ||
			Click.target.classList.contains("select2-selection__rendered")
		) {
			window.scrollTo({ top: Offset, behavior: "smooth" });
		}
		Remove.forEach((item) => {
			if (Click.target.classList.contains(item)) {
				Tabs_Btns.forEach((item) => item.classList.remove("Show"));
				Tabs.forEach((Remove) => Remove.classList.remove("Show"));
			}
		});
	};

	// The Setting Of Buy & Rent Buttons
	const Down_Menu = document.querySelectorAll(".Services .Search .Down li");
	const Top_Buttons = document.querySelectorAll(".Services .Search .TopIn a");
	Top_Buttons.forEach((button) => {
		button.onclick = (e) => {
			Down_Menu.forEach((nav) => {
				if (e.target.classList.contains("Buy")) {
					if (nav.classList.contains("Buy")) nav.style.display = "initial";
					if (nav.classList.contains("Rent")) nav.style.display = "none";
				}
				if (e.target.classList.contains("Rent")) {
					if (nav.classList.contains("Rent")) nav.style.display = "initial";
					if (nav.classList.contains("Buy")) nav.style.display = "none";
				}
			});
		};
	});

	// Count How Many Selection Type Number
	const TypesSpan = document.querySelector(".Services .Search .Down .box a[data-tab='.One'] span");
	const TypesMenu = document.querySelectorAll(".Services .Search .Show-Drob-Down .One input");
	TypesMenu.forEach((item) => {
		item.onclick = (e) => {
			if (e.target.checked) TypesSpan.textContent++;
			else TypesSpan.textContent--;
		};
	});

	// Put The Value Of The BKH On The Header
	const BKH_Btn = document.querySelector(".Services .Search .Down .BKH a");
	const BKH_Menu = document.querySelectorAll(".Services .Search .Show-Drob-Down .BKH input");
	BKH_Menu.forEach((input) => {
		input.onclick = (e) => {
			if (e.target.checked == true) {
				BKH_Btn.textContent += ` ${e.target.value}`;
			} else {
				let Text = BKH_Btn.textContent.split("");
				let res = Text.filter((num) => num != e.target.value).join("");
				BKH_Btn.textContent = res;
			}
		};
	});

	// =================== Search-Filters ==============
	let AllArrows = document.querySelectorAll(".Home .Search-Filters .filter-title .fa-chevron-up");
	AllArrows.forEach((item) => {
		item.parentElement.onclick = () => {
			const Catagory = item.parentElement.parentElement.querySelector(".Catagory");
			if (Catagory) Catagory.classList.toggle("ShowSibling");

			item.classList.toggle("Rotate");
			if (item.classList.contains("Rotate")) item.style.transform = "rotate(180deg)";
			else item.style.transform = "rotate(0deg)";
		};
	});

	// Show Picturs
	let Pics = document.querySelector(".Home .Search-Filters .Only .filter-title .button");
	Pics.onclick = (e) => e.target.classList.toggle("Move");

	// Select BKH Btns
	let BtnBKH = document.querySelectorAll(".Home .Search-Filters .BKH button");
	BtnBKH.forEach((item) => (item.onclick = (e) => e.target.classList.toggle("Active")));

	// Set Bathroom Counter
	let Increament = document.querySelector(".Home .Search-Filters .BathRoom .up");
	let Decreament = document.querySelector(".Home .Search-Filters .BathRoom .down");
	let Count = document.querySelector(".Home .Search-Filters .BathRoom .Count");
	Decreament.onclick = () => (Count.innerHTML > 0 ? Count.innerHTML-- : "");
	Increament.onclick = () => Count.innerHTML++;

	// Read More Btn
	let Read_More = document.querySelector(".Home .Search-Filters .Read-More");
	let Read_More_btn = document.querySelector(".Home .Search-Filters .Read-More-btn");
	Read_More_btn.onclick = () => {
		Read_More.classList.toggle("Active");
		if (Read_More_btn.innerHTML === "Read More") Read_More_btn.innerHTML = "Read Less";
		else Read_More_btn.innerHTML = "Read More";
	};

	// ================= Badget Range ==================
	let Range_Box = document.querySelectorAll(".Range-Box");
	let Budget_Cost1 = document.querySelector(".Services .Search .Down li.Budget #Budget span.Min-Budget");
	let Budget_Cost2 = document.querySelector(".Services .Search .Down li.Budget #Budget span.Max-Budget");
	setInterval(() => {
		Range_Box.forEach((item) => {
			let sliderOne = item.querySelector("#slider-1");
			let sliderTwo = item.querySelector("#slider-2");
			let displayValOne = item.querySelector("#Range-input-1");
			let displayValTwo = item.querySelector("#Range-input-2");
			let sliderTrack = item.querySelector(".slider-track");
			let sliderMaxValue = item.querySelector(" #slider-1").max;
			let minGap = 0;
			function slideOne() {
				if (parseInt(sliderTwo.value) - parseInt(sliderOne.value) <= minGap)
					sliderOne.value = parseInt(sliderTwo.value) - minGap;

				Budget_Cost1.textContent = 15000 + parseInt(sliderOne.value);
				displayValOne.textContent = 15000 + parseInt(sliderOne.value);
				fillColor();
			}
			function slideTwo() {
				if (parseInt(sliderTwo.value) - parseInt(sliderOne.value) <= minGap)
					sliderTwo.value = parseInt(sliderOne.value) + minGap;

				Budget_Cost2.textContent = 15000 + parseInt(sliderTwo.value);
				displayValTwo.textContent = 15000 + parseInt(sliderTwo.value);
				fillColor();
			}
			function fillColor() {
				percent1 = (sliderOne.value / sliderMaxValue) * 100;
				percent2 = (sliderTwo.value / sliderMaxValue) * 100;
				sliderTrack.style.background = `linear-gradient(to right, #dadae5 ${percent1}% , #8b3d88 ${percent1}% , #8b3d88 ${percent2}%, #dadae5 ${percent2}%)`;
			}
			sliderOne.setAttribute(oninput, slideOne());
			sliderTwo.setAttribute(oninput, slideTwo());
		});
	}, 10);
} catch (error) {
	console.log(error);
}

// ===================== Swiper ====================
var swiper = new Swiper("section.Home .Home-Swiper-Slides", {
	spaceBetween: 20,
	grabCursor: true,
	centeredSlides: true,
	loop: true,
	autoplay: {
		delay: 1500,
		disableOnInteraction: false,
	},
});

var swiper = new Swiper(".Services .Catagory2", {
	slidesPerView: "auto",
	spaceBetween: 20,
	grabCursor: true,
	loop: true,
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
});

var swiper = new Swiper(".Handpicked .Catagory", {
	slidesPerView: "auto",
	spaceBetween: 20,
	grabCursor: true,
	loop: true,
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
});

var swiper = new Swiper(".Cities .Catagory", {
	slidesPerView: "auto",
	spaceBetween: 20,
	grabCursor: true,
	loop: true,
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
});

var swiper = new Swiper(".Reviews .Catagory", {
	slidesPerView: "auto",
	spaceBetween: 20,
	grabCursor: true,
	loop: true,
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
});
