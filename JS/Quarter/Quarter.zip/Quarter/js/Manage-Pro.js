// ===================== Heart =====================
let Heart = document.querySelectorAll(".fa-heart");
if (Heart) Heart.forEach((item) => (item.onclick = (e) => e.target.classList.toggle("Heart")));

// ===================== NavBar =====================
let NavBar = document.querySelector("header .NavBar");
let OpenNavbar = document.querySelector("header .fa-bars");
let CloseNavbar = document.querySelector("header .NavBar .fa-times");
let Links = document.querySelectorAll("header .NavBar .Main");
OpenNavbar.onclick = () => {
	NavBar.classList.add("Active");
	OpenNavbar.style.opacity = "0";
	CloseNavbar.style.opacity = "1";
};
CloseNavbar.onclick = () => {
	NavBar.classList.remove("Active");
	OpenNavbar.style.opacity = "1";
	CloseNavbar.style.opacity = "0";
};
Links.forEach((link) => {
	link.onclick = () => {
		link.querySelector(".Nested-List").classList.toggle("Active");
		if (link.querySelector(".title .fas").className == "fas fa-minus Rotate") {
			link.querySelector(".title .fas").className = "fas fa-plus";
		} else {
			link.querySelector(".title .fas").className = "fas fa-minus Rotate";
		}
	};
});
var swiper = new Swiper(".Menage-Properties .tab-pane .swiper", {
	spaceBetween: 10,
	grabCursor: true,
	loop: true,
	autoplay: {
		delay: 3000,
		disableOnInteraction: false,
	},
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
});
var swiper = new Swiper("body.Short-listed .Listed .tab-pane .left", {
	spaceBetween: 10,
	grabCursor: true,
	loop: true,
	autoplay: {
		delay: 3000,
		disableOnInteraction: false,
	},
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
});
var swiper = new Swiper("body.Short-listed .Listed .tab-pane .right .Distance", {
	slidesPerView: "auto",
	grabCursor: true,
	loop: true,
});
