// ===================== Heart =====================
let Heart = document.querySelectorAll(".fa-heart");
if (Heart) Heart.forEach((item) => (item.onclick = (e) => e.target.classList.toggle("Heart")));

// ===================== NavBar =====================
let NavBar = document.querySelector("header .NavBar");
let OpenNavbar = document.querySelector("header .fa-bars");
let CloseNavbar = document.querySelector("header .NavBar .fa-times");
let Links = document.querySelectorAll("header .NavBar .Main");
OpenNavbar.onclick = () => {
	NavBar.classList.add("Active");
	OpenNavbar.style.opacity = "0";
	CloseNavbar.style.opacity = "1";
};
CloseNavbar.onclick = () => {
	NavBar.classList.remove("Active");
	OpenNavbar.style.opacity = "1";
	CloseNavbar.style.opacity = "0";
};
Links.forEach((link) => {
	link.onclick = () => {
		link.querySelector(".Nested-List").classList.toggle("Active");
		if (link.querySelector(".title .fas").className == "fas fa-minus Rotate") {
			link.querySelector(".title .fas").className = "fas fa-plus";
		} else {
			link.querySelector(".title .fas").className = "fas fa-minus Rotate";
		}
	};
});

// ======================= Tabs =======================
const Btns = document.querySelectorAll(".RailWay .btns a");
Btns.forEach((item) => {
	item.onclick = (e) => {
		Btns.forEach((item) => item.classList.remove("Active"));
		e.target.classList.add("Active");
	};
});

// =================== Slider-Images ==================
const Slider_Images = document.querySelector(".Slider-Images");
const Slider_Images_Main_Image = document.querySelector(".Slider-Images img[alt='Main-Image']");
const Close_Slider_Images = document.querySelector(".Slider-Images .fa.fa-times");
const Slider_Images_Nested_Images = document.querySelectorAll(".Slider-Images .swiper-wrapper img");
const Open_Slider_Images = document.querySelectorAll(".Banner");

Open_Slider_Images.forEach((img) => (img.onclick = () => Slider_Images.classList.add("Active")));
Close_Slider_Images.onclick = () => Slider_Images.classList.remove("Active");

Slider_Images_Nested_Images.forEach((Image) => {
	Image.onclick = (e) => {
		Slider_Images_Main_Image.src = e.target.dataset.image;
		Slider_Images_Nested_Images.forEach((img) => img.classList.remove("Active"));
		e.target.classList.add("Active");
	};
});

// ====================== Fixed Btns ==================
const btns = document.querySelector(".Amenities .Btns");
window.onscroll = () => {
	if (window.screenX <= 600) {
		if (window.scrollY < 20) {
			btns.style.bottom = "-50px";
		} else {
			btns.style.bottom = "40px";
		}
	}
};
// ====================== Swiper ======================
var swiper = new Swiper(".Banner .Content-Slider", {
	spaceBetween: 1,
	grabCursor: true,
	loop: true,
	autoplay: {
		delay: 3000,
		disableOnInteraction: false,
	},
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
});

var swiper = new Swiper(".Slider-Images .The-Lested-Images", {
	slidesPerView: "auto",
	spaceBetween: 20,
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
});

var swiper = new Swiper(".Amenities .Properties .Catagory", {
	slidesPerView: "auto",
	spaceBetween: 20,
	grabCursor: true,
	loop: true,
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
});
