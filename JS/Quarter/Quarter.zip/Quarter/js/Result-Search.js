try {
	// ===================== Heart =====================
	let Icons = document.querySelectorAll("i");
	if (Icons) Icons.forEach((item) => (item.onclick = (e) => e.target.classList.toggle("Favourit")));

	// ===================== NavBar =====================
	let NavBar = document.querySelector("header .NavBar");
	let OpenNavbar = document.querySelector("header .fa-bars");
	let CloseNavbar = document.querySelector("header .NavBar .fa-times");
	let Links = document.querySelectorAll("header .NavBar .Main");
	OpenNavbar.onclick = () => {
		NavBar.classList.add("Active");
		OpenNavbar.style.opacity = "0";
		CloseNavbar.style.opacity = "1";
	};
	CloseNavbar.onclick = () => {
		NavBar.classList.remove("Active");
		OpenNavbar.style.opacity = "1";
		CloseNavbar.style.opacity = "0";
	};
	Links.forEach((link) => {
		link.onclick = () => {
			link.querySelector(".Nested-List").classList.toggle("Active");
			if (link.querySelector(".title .fas").className == "fas fa-minus Rotate") {
				link.querySelector(".title .fas").className = "fas fa-plus";
			} else {
				link.querySelector(".title .fas").className = "fas fa-minus Rotate";
			}
		};
	});

	// =================== Search-Small ======================
	function formatState(state) {
		if (!state.id) return state.text;

		var $state = $(`<span class="Parent-Line"><span>${state.text}</span> <span>City</span>`);
		return $state;
	}
	$("#Search-Navbar select#Select-Home-box").select2({
		tags: true,
		templateResult: formatState,
		placeholder: "Please Search Here...",
		minimumInputLength: 1,
	});

	// ===================== Reload ====================
	setTimeout(() => (document.querySelector(".Reload-Page").style.display = "none"), 500);
	// ================ Open Filter & Sort =============
	let Filter_Menu = document.querySelector("aside.Search-Filters");
	let CLose_Filter_Menu = document.querySelector("aside.Search-Filters .return .fa-chevron-left");
	let Open_Filter_Menu = document.querySelector(".Filter-Sort-Buttons .Filter");
	let Sort_Menu = document.querySelector("#Sort-Menu");
	let Open_Sort = document.querySelector(".Filter-Sort-Buttons button#Sort");
	let Close_Sort = document.querySelector("#Sort-Menu .fa-times");

	Open_Filter_Menu.onclick = () => Filter_Menu.classList.add("Active");
	CLose_Filter_Menu.onclick = () => Filter_Menu.classList.remove("Active");
	Open_Sort.onclick = () => Sort_Menu.classList.add("Active");
	Close_Sort.onclick = () => Sort_Menu.classList.remove("Active");
	Sort_Menu.querySelectorAll(".fas.fa-check").forEach((icon) => {
		icon.parentElement.onclick = () => {
			Sort_Menu.querySelectorAll(".fas.fa-check").forEach((i) => i.classList.remove("Show"));
			icon.classList.add("Show");
		};
	});

	// =================== Five Section ===============
	const AllButtons = document.querySelectorAll(".Five .swiper .swiper-wrapper .swiper-slide");
	AllButtons.forEach((item) => (item.onclick = () => item.classList.toggle("Active")));

	// =================== Search-Filters ==============
	let AllArrows = document.querySelectorAll(".Search-Filters .filter-title .fa-chevron-up");
	AllArrows.forEach((item) => {
		item.parentElement.onclick = () => {
			const Catagory = item.parentElement.parentElement.querySelector(".Catagory");
			if (Catagory) Catagory.classList.toggle("ShowSibling");

			item.classList.toggle("Rotate");
			if (item.classList.contains("Rotate")) item.style.transform = "rotate(180deg)";
			else item.style.transform = "rotate(0deg)";
		};
	});

	// =====================
	let ButtonsBKH = document.querySelectorAll(".Search-Filters .BKH button");
	ButtonsBKH.forEach((item) => (item.onclick = (e) => e.target.classList.toggle("Active")));

	// =====================
	let Only = document.querySelector(".Search-Filters .Only .filter-title .button");
	Only.onclick = (e) => e.target.classList.toggle("Move");

	// =====================
	let Up = document.querySelector(".Search-Filters .BathRoom .up");
	let Down = document.querySelector(".Search-Filters .BathRoom .down");
	let Count = document.querySelector(".Search-Filters .BathRoom .Count");
	Up.onclick = () => Count.innerHTML++;
	Down.onclick = () => (Count.innerHTML > 0 ? Count.innerHTML-- : "");

	// ================= Small-Icons ===================
	let Small = document.querySelectorAll(".One .left .Small-Images img");
	let Big = document.querySelectorAll(".One .left .Big-Images .Main-img");
	Small.forEach((event) => {
		event.onclick = () => {
			Small.forEach((el) => (el.style.opacity = "0.5"));
			event.style.opacity = "0.99";
			Big.forEach((el) => (el.style.opacity = "0"));
			document.querySelector(event.dataset.img).style.opacity = "0.99";
		};
	});

	// ================= Badget Range ==================
	let Range_Box = document.querySelectorAll(".Range-Box");
	setInterval(() => {
		Range_Box.forEach((item) => {
			let sliderOne = item.querySelector("#slider-1");
			let sliderTwo = item.querySelector("#slider-2");
			let displayValOne = item.querySelector("#Range-input-1");
			let displayValTwo = item.querySelector("#Range-input-2");
			let sliderTrack = item.querySelector(".slider-track");
			let sliderMaxValue = item.querySelector(" #slider-1").max;
			let minGap = 0;
			sliderOne.setAttribute(oninput, slideOne());
			sliderTwo.setAttribute(oninput, slideTwo());
			function slideOne() {
				if (parseInt(sliderTwo.value) - parseInt(sliderOne.value) <= minGap)
					sliderOne.value = parseInt(sliderTwo.value) - minGap;

				displayValOne.textContent = 15000 + parseInt(sliderOne.value);
				fillColor();
			}
			function slideTwo() {
				if (parseInt(sliderTwo.value) - parseInt(sliderOne.value) <= minGap)
					sliderTwo.value = parseInt(sliderOne.value) + minGap;

				displayValTwo.textContent = 15000 + parseInt(sliderTwo.value);
				fillColor();
			}
			function fillColor() {
				percent1 = (sliderOne.value / sliderMaxValue) * 100;
				percent2 = (sliderTwo.value / sliderMaxValue) * 100;
				sliderTrack.style.background = `linear-gradient(to right, #dadae5 ${percent1}% , #8b3d88 ${percent1}% , #8b3d88 ${percent2}%, #dadae5 ${percent2}%)`;
			}
		});
	}, 10);
} catch (error) {
	console.log("");
}

// ===================== Swiper ====================
var swiper = new Swiper(".Parent .Two .left", {
	spaceBetween: 30,
	grabCursor: true,
	loop: true,
	autoplay: {
		delay: 3500,
		disableOnInteraction: false,
	},
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
});

var swiper = new Swiper(".Three .swiper", {
	slidesPerView: "auto",
	spaceBetween: 20,
	grabCursor: true,
	loop: true,
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
});

var swiper = new Swiper(".Five .swiper", {
	slidesPerView: "auto",
	spaceBetween: 10,
	grabCursor: true,
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
});

var swiper = new Swiper(".Distance.swiper", {
	slidesPerView: "auto",
	spaceBetween: 0,
	grabCursor: true,
});
